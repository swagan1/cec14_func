1. run the following command in Matlab window:
   mex cec14_func.cpp -DWINDOWS
2. Then you can use the test functions as the following example:
   f = cec14_func(x,func_num); 
   here x is a D*pop_size matrix.
